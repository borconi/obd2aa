package uk.co.boconi.emil.obd2aa;

import android.support.v4.content.FileProvider;

/**
 * Created by Emil on 25/09/2017.
 */
public class GenericFileProvider extends FileProvider {

}
